import{b as a}from"../chunks/entry.BHqCWWo6.js";export{a as start};
